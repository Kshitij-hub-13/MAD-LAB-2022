class Vikarn extends Kauravs
{
    void kind()
    {
        System.out.println("Vikarn was kind , obedient and fighter in Kauravs");
    }
}