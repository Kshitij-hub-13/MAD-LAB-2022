class Bharatvanshi
{
    void fight()
    {
        System.out.println("All Bharatvanshi were fighters");
    }
}