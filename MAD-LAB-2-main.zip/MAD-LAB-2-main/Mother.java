public class Mother
{
    public void show()
    {
    int x;
    System.out.println("Mother class");
    }
}